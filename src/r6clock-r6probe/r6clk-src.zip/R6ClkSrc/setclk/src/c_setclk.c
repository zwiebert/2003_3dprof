#include "setclk_inc.h"
#include <Windows.h>

#define EXP1 1 // new divider optimization


#define MAX_FB_DIV 150   // upto 255
#define MIN_FB_DIV 2     // at least 2
#define MAX_REF_DIV 150  // upto 255 
#define MIN_REF_DIV 4    // at least 2

#define MAX_KHZ_DIFF 8000  // clocks have to be higher than DESIRED_KHZ - MAX_KHZ_DIFF


static void  __cdecl imp_c_setclk_setclock(float desired_vpuclk, float desired_memclk, int locked);

#if EXP1
static float calc_optimal_dividers_for_given_clock(unsigned desired_vpu_khz, unsigned desired_mem_khz,
                                                   unsigned vpu_post_divider, unsigned mem_post_divider,
                                                   unsigned *out_reference_divider,
                                                   unsigned *out_vpu_feedback_divider,
                                                   unsigned *out_mem_feedback_divider);
#else
static float calc_optimal_dividers_for_given_clock(const float maxclk,
                                                   float desired_clock,
                                                   unsigned post_divider,
                                                   unsigned *out_reference_divider,
                                                   unsigned *out_feedback_divider);
#endif

// --------------------------------------
//  Name: r6probe_setclk
//  Desc: Set RADEON clock freqs
// --------------------------------------
void  __cdecl c_setclk_setclock(float desired_vpuclk, float desired_memclk, int locked)
{
  float vpuclk, memclk;


  // do clokcing in step-by-step to avoid screen corruption
  if (!locked && !c_setclk_getclock(&vpuclk, &memclk))
  {
    for (;;) {
      int vpu_increment = 0;
      int mem_increment = 0;
#define CLK_INC 8
#define SLEEP_MS 15
      if (desired_vpuclk != 0.0 && abs((int)(vpuclk - desired_vpuclk)) > CLK_INC)
        vpu_increment = (vpuclk < desired_vpuclk ? CLK_INC: -CLK_INC); 
      if (desired_memclk != 0.0 && abs((int)(memclk - desired_memclk)) > CLK_INC)
        mem_increment = (memclk < desired_memclk ? CLK_INC : -CLK_INC);
      if (vpu_increment == 0 && mem_increment == 0)
        break;

      imp_c_setclk_setclock(vpuclk += vpu_increment, memclk += mem_increment, 0);
      Sleep(SLEEP_MS);
    }
  }


    imp_c_setclk_setclock(desired_vpuclk, desired_memclk, locked);
#undef CLK_INC
#undef SLEEP_MS  
}

static void  __cdecl imp_c_setclk_setclock(float desired_vpuclk, float desired_memclk, int locked)
{
  // external options
  extern int setclk_feature_divopt;
  // automatic variables
  unsigned hw_reg, reference_divider,
    vpu_feedback_divider, vpu_post_divider,
    mem_feedback_divider, mem_post_divider;
  unsigned char is_locked; // if mem and vpu clock are coupled
  float vpuclk, memclk, maxclk;

#if 0
  if (!locked && !c_setclk_getclock(&vpuclk, &memclk))
  {
      int vpu_increment = 0;
      int mem_increment = 0;
#define CLK_INC 15
      if (abs((int)(vpuclk - desired_vpuclk)) > CLK_INC)
        vpu_increment = (vpuclk < desired_vpuclk ? -CLK_INC: CLK_INC); 
      if (abs((int)(memclk - desired_memclk)) > CLK_INC)
        mem_increment = (memclk < desired_memclk ? -CLK_INC : CLK_INC);
#undef CLK_INC
      if (vpu_increment != 0 || mem_increment != 0) {
        c_setclk_setclock(desired_vpuclk + vpu_increment, desired_memclk + mem_increment, 0);
        Sleep(20);
      }
  }
#endif

  // get hardware registers first
  hw_reg = r6probe_readpll(RADEON_XCLK_CNTL);
  is_locked        = ((hw_reg & 0x7) == 0x7);
  vpu_post_divider = GET_VPU_POST_DIV(hw_reg);

  hw_reg = r6probe_readpll(RADEON_MCLK_CNTL);
  mem_post_divider = GET_MEM_POST_DIV(hw_reg);

  hw_reg = r6probe_readpll(RADEON_X_MPLL_REF_FB_DIV);
  reference_divider = GET_REF_DIV(hw_reg);

  // initilize variables
  if (locked) desired_memclk = desired_vpuclk;
  vpuclk = desired_vpuclk;
  memclk = desired_memclk;
  maxclk = ((vpuclk > memclk) ? vpuclk : memclk) + 1.0f;

#if !EXP1
  // experimental: try to minimize gap between desired clocks and actual clock by changing reference_divider
  if (setclk_feature_divopt > 0) {
    vpuclk = calc_optimal_dividers_for_given_clock(maxclk, vpuclk, mem_post_divider, &reference_divider, &vpu_feedback_divider);
    memclk = calc_optimal_dividers_for_given_clock(maxclk, memclk, vpu_post_divider, &reference_divider, &mem_feedback_divider);

    if (desired_vpuclk < vpuclk || (desired_vpuclk - vpuclk) > 14.0)
      return;
    if (desired_memclk < memclk || (desired_memclk - memclk) > 14.0)
      return;
  }

  // calulate new feedback dividers
  mem_feedback_divider = (unsigned)((reference_divider * mem_post_divider * memclk) / (2.0f * setclk_PLLData.reference_freq));
  vpu_feedback_divider = (unsigned)((reference_divider * vpu_post_divider * vpuclk) / (2.0f * setclk_PLLData.reference_freq));
#else
  if (setclk_feature_divopt > 0) {
    unsigned vpu_khz = (unsigned)(vpuclk * 1000.0);
    unsigned mem_khz = (unsigned)(memclk * 1000.0);
    calc_optimal_dividers_for_given_clock(vpu_khz, mem_khz, vpu_post_divider, mem_post_divider, &reference_divider, &vpu_feedback_divider, &mem_feedback_divider);
  } else {
    mem_feedback_divider = (unsigned)((reference_divider * mem_post_divider * memclk) / (2.0f * setclk_PLLData.reference_freq));
    vpu_feedback_divider = (unsigned)((reference_divider * vpu_post_divider * vpuclk) / (2.0f * setclk_PLLData.reference_freq));
  }
#endif

#if 1
  // sanity checks
  {
    float dbg_memclk = CALC_MEM_CLOCK(setclk_PLLData.reference_freq, reference_divider, mem_post_divider, mem_feedback_divider);
    float dbg_vpuclk = CALC_VPU_CLOCK(setclk_PLLData.reference_freq, reference_divider, vpu_post_divider, vpu_feedback_divider);
    printf("debug_info: ref_div=%u, mem_fb_div=%u, vpu_fb_div=%u\n", reference_divider, mem_feedback_divider, vpu_feedback_divider);
    if (!(190 <= dbg_memclk && dbg_memclk < 500)) {
      puts("######## error in program: dbg_memclk out of range");
      return;
    }
    if (!(190 <= dbg_vpuclk && dbg_vpuclk < 500)) {
      puts("######### error in program: dbg_vpuclk out of range");
      return;
    }
  }


#endif

  // build new register content
  SET_REF_DIV(hw_reg, reference_divider);
  SET_MEM_FB_DIV(hw_reg, mem_feedback_divider);
  SET_VPU_FB_DIV(hw_reg, vpu_feedback_divider);

  // write register
  r6probe_writepll(RADEON_X_MPLL_REF_FB_DIV, 0x00ffffff, hw_reg);

#if 0
  // writing locked state to R300 may crash (?)
  r6probe_writepll(RADEON_XCLK_CNTL, 7, (locked ? 7 : 2));
#endif
}

#if !EXP1
// The problem is: mem and vpu share the same reverence_divider
// So better rewrite this function to take both clock freqencies as parameters
static float
calc_optimal_dividers_for_given_clock(const float max_clock, float desired_clock, unsigned post_divider, unsigned *out_reference_divider, unsigned *out_feedback_divider)
{
  unsigned i_ref_div, i_fb_div;
  double best_clock = -1;
  double best_clock_diff = desired_clock;
  unsigned best_ref_div, best_fb_div;
  double base_clock = setclk_PLLData.reference_freq;
  double clock, clock_diff;
  double multiplier;
  int best_found = 0;

  for (i_ref_div = MAX_REF_DIV; i_ref_div >= MIN_REF_DIV; --i_ref_div) {
    for (i_fb_div = MIN_FB_DIV; i_fb_div <= MAX_FB_DIV; ++i_fb_div) {
      multiplier = (2.0f *(float)i_fb_div) / ((float)i_ref_div * (float)post_divider);
      clock = base_clock * multiplier;
      if (clock < 0.0 || clock > 999000.0) continue;
      if (clock > desired_clock) continue;
      clock_diff = desired_clock - clock;
      if (best_clock_diff < (clock_diff + 1.5)) continue;
      if (max_clock >= CALC_VPU_CLOCK(base_clock, i_ref_div, post_divider, MAX_FB_DIV)) continue;

      best_clock      = clock;
      best_clock_diff = clock_diff;
      best_ref_div    = i_ref_div;
      best_fb_div     = i_fb_div;
      best_found      = 1;


    }
  }

  if (best_found) {
    *out_reference_divider = best_ref_div;
    *out_feedback_divider = best_fb_div;
  }

  return (float)best_clock;
}
#else

#define get_ref_khz() ((unsigned)(setclk_PLLData.reference_freq * 1000.0))

static float calc_optimal_dividers_for_given_clock(unsigned desired_vpu_khz, unsigned desired_mem_khz,
                                   unsigned vpu_post_divider, unsigned mem_post_divider,
                                   unsigned *out_reference_divider,
                                   unsigned *out_vpu_feedback_divider,
                                   unsigned *out_mem_feedback_divider)
{
  unsigned i_ref_div,    i_vfb_div,    i_mfb_div;
  unsigned best_ref_div, best_vfb_div, best_mfb_div;
  unsigned base_clock  = get_ref_khz();
  double best_vpu_offness = 99999.9;
  double best_mem_offness = 99999.9;

  int best_found = 0;

  for (i_ref_div      = MAX_REF_DIV; i_ref_div  >= MIN_REF_DIV; --i_ref_div) {
    for (i_vfb_div    = MIN_FB_DIV;  i_vfb_div  <= MAX_FB_DIV;  ++i_vfb_div) {
      double tem_vpu_offness;
      unsigned tem_vpu_khz  = CALC_VPU_CLOCK(base_clock, i_ref_div, vpu_post_divider, i_vfb_div);
      if (tem_vpu_khz > desired_vpu_khz)
        break;
      if (tem_vpu_khz < desired_vpu_khz - MAX_KHZ_DIFF)
        continue; // optimization
      tem_vpu_offness = (double)(desired_vpu_khz - tem_vpu_khz) / (double)desired_vpu_khz;

      for (i_mfb_div  = MIN_FB_DIV;  i_mfb_div  <= MAX_FB_DIV;  ++i_mfb_div) {
        double tem_mem_offness;
        unsigned tem_mem_khz  = CALC_VPU_CLOCK(base_clock, i_ref_div, mem_post_divider, i_mfb_div);
        if (tem_mem_khz > desired_mem_khz)
          break;
        if (tem_mem_khz < desired_mem_khz - MAX_KHZ_DIFF)
          continue; // optimization
        tem_mem_offness = (double)(desired_mem_khz - tem_mem_khz) / (double)desired_mem_khz;

        if ((best_vpu_offness + best_mem_offness) > (tem_vpu_offness + tem_mem_offness)) {
          best_found = 1;
          best_ref_div = i_ref_div;
          best_vfb_div = i_vfb_div;
          best_mfb_div = i_mfb_div;
          best_vpu_offness = tem_vpu_offness;
          best_mem_offness = tem_mem_offness;
        }




      }}}

  if (best_found) {
    *out_reference_divider    = best_ref_div;
    *out_vpu_feedback_divider = best_vfb_div;
    *out_mem_feedback_divider = best_mfb_div;
  }

  return 0;
}
#endif
