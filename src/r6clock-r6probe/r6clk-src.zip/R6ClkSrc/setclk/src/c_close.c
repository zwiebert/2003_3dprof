#include "setclk_inc.h"

void  __cdecl c_setclk_close()
{
  r6probe_close();
}