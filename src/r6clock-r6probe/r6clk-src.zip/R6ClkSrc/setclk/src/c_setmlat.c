#include "setclk_inc.h"


// -----------------------------------------
//  Name: setclk_getmlat
//  Desc: Get RADEON memory latency timers
// -----------------------------------------
void  __cdecl c_setclk_setmlat(int latidx)
{
  unsigned latency = 0;

  switch(latidx) {
  case 0: latency = LATENCY_FAST; break;
  case 1: latency = LATENCY_MEDIUM; break;
  default: return;
  }

  r6probe_writemmr(RADEON_MEM_INIT_LAT_TIMER, 0xffffffff, latency);
}
