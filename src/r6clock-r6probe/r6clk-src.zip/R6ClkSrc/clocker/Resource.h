//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by clocker.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLOCKER_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_LIM_MIN_CORE           1001
#define IDC_EDIT_LIM_MIN_MEM            1002
#define IDC_EDIT_PRE_SLOW_CORE          1003
#define IDC_EDIT_CORE_MAX               1004
#define IDC_EDIT_LIM_MAX_CORE           1004
#define IDC_EDIT_LIM_MAX_MEM            1005
#define IDC_STATIC_CORE                 1006
#define IDC_STATIC_MEM                  1007
#define IDC_BUTTON_GET                  1008
#define IDC_SLIDER_CORE                 1009
#define IDC_SLIDER_MEM                  1010
#define IDC_BUTTON_SET                  1011
#define IDC_EDIT_PRE_SLOW_MEM           1012
#define IDC_EDIT_PRE_NORMAL_CORE        1013
#define IDC_EDIT_PRE_NORMAL_MEM         1014
#define IDC_EDIT_PRE_FAST_CORE          1015
#define IDC_EDIT_PRE_FAST_MEM           1016
#define IDC_EDIT_PRE_ULTRA_CORE         1017
#define IDC_EDIT_PRE_ULTRA_MEM          1018
#define IDC_BUTTON_PRE_SLOW             1019
#define IDC_BUTTON_PRE_NORMAL           1020
#define IDC_BUTTON_PRE_FAST             1021
#define IDC_BUTTON_PRE_ULTRA            1022
#define IDC_BUTTON_PREF_OK              1023
#define IDC_BUTTON_PREF_CANCEL          1024
#define IDC_STATIC_DEVID_LABEL          1025
#define IDC_STATIC_DEVID_VALUE          1026
#define IDC_STATIC_VENVID_LABEL         1027
#define IDC_STATIC_VENID_VALUE          1028
#define IDC_STATIC_MESSAGE              1029
#define IDC_BUTTON_PRE_SET_MIN          1030
#define IDC_BUTTON_PRE_SET_SLOW         1031
#define IDC_BUTTON_PRE_SET_NORMAL       1032
#define IDC_BUTTON_PRE_SET_FAST         1033
#define IDC_BUTTON_PRE_SET_ULTRA        1034
#define IDC_BUTTON_PRE_SET_MAX          1035
#define IDC_SPIN_CORE_MAX               1036
#define IDC_SPIN_LIM_MIN_MEM            1037
#define IDC_SPIN_PRE_SLOW_CORE          1038
#define IDC_SPIN_PRE_SLOW_MEM           1039
#define IDC_SPIN_PRE_NORMAL_CORE        1040
#define IDC_SPIN_PRE_NORMAL_MEM         1041
#define IDC_SPIN_PRE_FAST_CORE          1042
#define IDC_SPIN_PRE_FAST_MEM           1043
#define IDC_SPIN_PRE_ULTRA_CORE         1044
#define IDC_SPIN_PRE_ULTRA_MEM          1045
#define IDC_SPIN_LIM_MAX_CORE           1046
#define IDC_SPIN_LIM_MAX_MEM            1047
#define IDC_BUTTON1                     1048
#define IDC_BUTTON_DIAG_PRINT           1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
